import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.engine import CapaEngine
from src.core.smart_link import generar_smart_link, validar_smart_link
from src.core.telemetry import PilotTelemetryManager, FailClosedTelemetryError
from src.server.mcp_server import handle_rpc_request

class TestCapaPilot(unittest.TestCase):
    def setUp(self):
        self.telemetry = PilotTelemetryManager(fail_closed=True)
        self.engine = CapaEngine(telemetry=self.telemetry)
        self.dni_piloto = "29269803"
        self.poliza_auto = 7894561
        self.poliza_hogar = 7894562

    def test_01_consulta_polizas(self):
        res = self.engine.consultar_polizas(self.dni_piloto)
        self.assertTrue(res["exito"])
        self.assertEqual(res["total"], 2)

    def test_02_cobertura_cristales_y_auxilio(self):
        res_c = self.engine.verificar_cobertura(self.poliza_auto, "rotura de cristal")
        self.assertEqual(res_c["veredicto"], "COBERTURA_CONFIRMADA")
        self.assertEqual(res_c["clausula_contractual"], "CA-CR 2.1")

        res_a = self.engine.verificar_cobertura(self.poliza_auto, "robo de auxilio")
        self.assertEqual(res_a["veredicto"], "COBERTURA_CONFIRMADA")
        self.assertEqual(res_a["clausula_contractual"], "CA-RA 3.0")

    def test_03_franquicia_fija(self):
        res_f = self.engine.verificar_cobertura(self.poliza_auto, "franquicia")
        self.assertEqual(res_f["veredicto"], "COBERTURA_CONFIRMADA")
        self.assertEqual(res_f["clausula_contractual"], "CP-FR 0.1")

    def test_04_guardrail_sin_evidencia(self):
        res_x = self.engine.verificar_cobertura(self.poliza_auto, "avion o helicoptero")
        self.assertEqual(res_x["veredicto"], "SIN_EVIDENCIA_DIRECTA")
        self.assertIsNone(res_x["cubierto"])

    def test_05_smart_link_tokens(self):
        link = generar_smart_link(str(self.poliza_auto), self.dni_piloto, canal="gemini")
        val = validar_smart_link(link["token"])
        self.assertTrue(val["valido"])
        self.assertEqual(val["datos"]["poliza_id"], str(self.poliza_auto))

    def test_06_mcp_rpc_protocol(self):
        req = {
            "jsonrpc": "2.0",
            "id": 100,
            "method": "tools/call",
            "params": {
                "name": "verificar_cobertura",
                "arguments": {"poliza_numero": self.poliza_auto, "consulta": "granizo"}
            }
        }
        res = handle_rpc_request(req)
        self.assertEqual(res["id"], 100)
        self.assertIn("COBERTURA_CONFIRMADA", res["result"]["content"][0]["text"])

    def test_07_telemetry_fail_closed_security(self):
        events = self.telemetry.get_recent_events()
        # Verificar que la telemetría anonimiza el DNI
        for ev in events:
            self.assertNotIn(self.dni_piloto, ev["anonymous_user_id"])
            self.assertEqual(len(ev["anonymous_user_id"]), 16)

if __name__ == "__main__":
    unittest.main()

    def test_08_api_server_endpoints(self):
        from src.server.api_server import handle_http_request
        
        # Test health
        code, body = handle_http_request("GET", "/health")
        self.assertEqual(code, 200)
        self.assertEqual(body["status"], "online")
        
        # Test policies by identificationNumber (Sancor standard param)
        code, body = handle_http_request("GET", "/v1/policies", query_params={"identificationNumber": "29269803"})
        self.assertEqual(code, 200)
        self.assertTrue(body["exito"])
        self.assertEqual(body["total"], 2)
        
        # Test coverage verification
        code, body = handle_http_request("POST", "/v1/coverage/verify", body={"poliza_numero": 7894561, "consulta": "granizo"})
        self.assertEqual(code, 200)
        self.assertEqual(body["veredicto"], "COBERTURA_CONFIRMADA")

# Capa Seguros — Omni-LLM Infrastructure

Infraestructura de inteligencia aseguradora independiente que opera sobre APIs oficiales de aseguradoras (Sancor Seguros) y se expone de forma agnóstica a modelos de lenguaje (ChatGPT, Gemini y clientes MCP).

## Arquitectura de Carpetas
- `src/core/`: Motor semántico, normalización contractual, Smart Links efímeros y telemetría fail-closed.
- `src/server/`: Servidor Model Context Protocol (JSON-RPC 2.0).
- `config/`: Esquemas OpenAPI 3.1 (Custom GPT Actions) y Gemini Function Calling.
- `tests/`: Pruebas unitarias de cobertura, guardrails y criptografía de tokens.
- `.github/workflows/`: Pipeline de Integración Continua (CI).

## Ejecución de Pruebas
```bash
python3 -m unittest discover -s tests -p "test_*.py"
```
